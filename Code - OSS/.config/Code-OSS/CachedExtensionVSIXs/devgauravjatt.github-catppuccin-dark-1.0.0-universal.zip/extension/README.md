## 🥣 Github Catppuccin Dark

### A unique dark theme for vscode, Build with Github + catppuccin.

## 🖼 Preview

### 🖼 Dark : -----

![preview](https://github.com/devgauravjatt/github-catppuccin-dark/raw/HEAD/images/preview3.png)

### 🖼 Dark Plus : -----

![preview](https://github.com/devgauravjatt/github-catppuccin-dark/raw/HEAD/images/preview4.png)

### 🖼 Dark : -----

![preview](https://github.com/devgauravjatt/github-catppuccin-dark/raw/HEAD/images/preview.png)

### 🖼 Dark Plus : -----

![preview](https://github.com/devgauravjatt/github-catppuccin-dark/raw/HEAD/images/preview2.png)
